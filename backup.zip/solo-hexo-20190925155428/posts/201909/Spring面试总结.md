title: Spring面试总结
date: '2019-09-23 20:49:38'
updated: '2019-09-23 20:49:38'
tags: [Spring, 面试, 总结]
permalink: /articles/2019/09/23/1569242978787.html
---
- # Spring
<!-- toc -->

  * [Spring的组成](#Spring的组成)
  * [Spring IOC （Inversion Of Control）](#Spring-IOC-（Inversion-Of-Control）)
  * [IOC容器中Bean的定义](#IOC容器中Bean的定义)
  * [IOC的实例化过程](#IOC的实例化过程)
  * [Spring AOP](#Spring-AOP)
  * [SpringBoot有哪些优点？ （未完成  :orange:）](#SpringBoot有哪些优点？-（未完成-orange）)
  * [@SpringBootApplication注解](#SpringBootApplication注解)
  * [SpringBoot的启动流程？](#SpringBoot的启动流程？)
- [Bean的生命周期](#Bean的生命周期)
  * [BeanFactory和FactoryBean的区别](#BeanFactory和FactoryBean的区别)
- [Spring中bean的循环依赖问题 :star:](#Spring中bean的循环依赖问题-star)
  * [@Autowired 与@Resource的区别](#Autowired-与Resource的区别)
  * [@Configuration](#Configuration)
- [Spring中Mybatis的原理 :star::star::star:](#Spring中Mybatis的原理-starstarstar)
  * [mybatis中的${}和#{}的区别](#mybatis中的和的区别)
  * [MyBatis 一级缓存和二级缓存](#MyBatis-一级缓存和二级缓存)
  * [Spring中拦截器与过滤器的区别](#Spring中拦截器与过滤器的区别)
- [Spring中的事务原理 :star:](#Spring中的事务原理-star)
  * [事务传播行为](#事务传播行为)
  * [事务](#事务)
  * [SpingBoot自动配置实现](#SpingBoot自动配置实现)

<!-- tocstop -->
- #### Spring的组成
  1. Spring Core： 基础,可以说 Spring 其他所有的功能都需要依赖于该类库。主要提供 IoC 依赖注入功能。
  2. Spring AOP ：提供了面向方面的编程实现。
  3. Spring JDBC : Java数据库连接。
  4. Spring JMS ：Java消息服务。
  5. Spring ORM : 用于支持Mybatis等ORM工具。
  6. Spring Web : 为创建Web应用程序提供支持。
  7. Spring Test : 提供了对 JUnit 和 TestNG 测试的支持。

- #### Spring IOC （Inversion Of Control）
  - IOC是一种设计思想，用来解决对象之间耦合度过高的问题。Spring通过IOC容器实现对象的创建和管理，然后通过依赖注入的方式实现对象的调用。
  - IOC容器的底层数据结构为Map集合。

- #### IOC容器中Bean的定义
  - Resource定位：通过XML配置和注解获取bean的定义。
  - BeanDefinition载入：将resource定位到的信息，保存到bean的定义中；
  - BeanDefinition注册：将bean的定义信息发布到IOC容器中。

- #### IOC的实例化过程
  1. 准备上下文信息；
  2. 创建BeanFactory；
  3. 对BeanFactory进行功能填充；
  4. 激活各种BeanFactoryPostProcessor处理器；
  5. registerBeanPostProcessors 注册组件后置处理器，这种处理器用于拦截bean的创建过程
  6. 初始化消息组件和事件广播器
  7. 注册事件监听器
  8. Bean的初始化
  9. 刷新容器

- #### Spring AOP
  - AOP是一种利用动态代理的方式为系统动态添加功能的技术。
  - AOP可以实现应用的业务逻辑和系统级服务（日志管理、权限控制等）的分离，从而减少重复代码，降低各个模块之间的耦合度，便于系统应用的扩展和维护。
  - 实现动态代理的两种方式：JDK Proxy 和 Cglib
    1. 初始化Advisor链，将所有的通知都注册到通知链上
    2. 通过动态代理的方式生成代理对象（拦截器）
    3. 在调用方法进行拦截

- #### SpringBoot有哪些优点？ （未完成  :orange:）
  1. 简化开发、方便解耦
      通过Spring的IOC容器，我们将对象之间的依赖关系交给Spring管理，实现了模块之间的解耦，增强了系统的可扩展性和可维护性。
  2. AOP编程支持
     AOP通过动态代理（JDK（接口）和CGLib（类））的方式，为系统动态的添加功能。
     通过AOP可以实现应用的业务逻辑和系统级服务的分离，并且可以在系统运行时，将系统级服务插入到需要的地方。
  3. 采用配置的方式实现多种优秀框架的集成
  
- #### @SpringBootApplication注解
  - @SpringBootApplication注解等于@SpringBootConfiguration、@EnableAutoConfiguration和@ComponetScan三个注解的组合。
  1. @SpringBootConfiguration: 用来声明当前类是一个配置类
  2. @EnableAutoConfiguration: Springboot实现自动化配置的核心注解，通过这个注解把spring应用所需的bean注入容器中
  3. @ComponetSan : 组件扫描注解，将所有Bean组件都加载到IOC容器中

- #### SpringBoot的启动流程？
  1. 当运行SpringApplication的main方法时,会调用Application.run()，进行会调用SpringApplication的实例化和初始化配置。
  2. SpringApplicatio实例化完成并且完成配置后调用run()方法，并启动应用监听器开始监听SpringApplication的启动。
  3. 加载SpringBoot配置环境(ConfigurableEnvironment),并将配置环境(Environment)加入到监听器对象中(SpringApplicationRunListeners)。
  4. 通过BeanUtils实例化ConfigurableApplicationContext(应用配置上下文)上下文对象，并返回。
  5. prepareContext()方法将listeners、environment、applicationArguments、banner等重要组件与上下文对象关联。
  6. refreshContext(context)刷新应用上下文容器,并完成bean的实例化。
  7. 最后返回ApplicationContext应用上下文容器对象。

- ### Bean的生命周期 
  1. 通过扫描XML配置文件或者注解查找Bean的定义。
  2. 实例化Bean对象，并设置对象属性。
  3. 如果Bean实现了BeanNameAware接口的setBeanName方法，则调用该方法。
  4. 如果Bean实现了BeanFactoryAware接口的setBeanFactory方法，则调用该方法。
  5. 如果Bean实现了ApplicationContextAware接口的setApplicationContext方法，则调用该方法。
  6. 如果Bean实现了BeanPostProcessor接口的postProcessBeforeInitialization方法，则调用该方法。 
  7. 如果Bean自定义了初始化方法，则调用该方法
  8. 如果Bean实现了BeanPostProcessor接口的postProcessAfterInitialization方法，则调用该方法。
  9. bean对象可以正常使用。
  10. 如果容器关闭，Bean实现了DisposableBean接口，则调用该接口的destory()方法。

- #### BeanFactory和FactoryBean的区别
   1. IoC容器的顶级接口，是实现IOC容器的基本规范，负责对bean的创建，访问等工作。
   2. 可以返回bean的实例的工厂bean，通过实现该接口可以对bean进行一些额外的操作，例如根据不同的配置类型返回不同类型的bean，简化xml配置等。

- ### Spring中bean的循环依赖问题 :star:
  1. 多例的bean无法解决循环依赖问题，因为Spring 容器不缓存“prototype”（多例）作用域的bean，因此无法提前暴露一个创建中的bean。
  2. 单例的bean：
    - 对于构造器注入无法解决循环依赖问题，构造器无法创建循环依赖的bean，会直接抛出BeanCurrentlyInCreationException异常。
    - 对于setter注入方式，在bean的实例化时会将bean存储的单例缓存中，需要注入时直接从缓存总获取。
 
- #### @Autowired 与@Resource的区别
  1. @Autowired与@Resource都可以用来装配bean. 都可以写在字段上,或写在setter方法上。
  2. @Autowired默认按类ByType装配，默认情况下必须要求依赖对象必须存在。@Resource，默认按照名称进行装配，名称可以通过name属性进行指定。
  3. @Autowired注解属于spring。@Resource注解属于javaEE。

- #### @Configuration
  - @Configuration用于定义配置类，可替换xml配置文件，被注解的类内部包含有一个或多个被@Bean注解的方法，这些方法将会被AnnotationConfigApplicationContext或AnnotationConfigWebApplicationContext类进行扫描，并用于构建bean定义，初始化Spring容器。
  - @Configuration可以用于导入xml配置

- ### Spring中Mybatis的原理 :star::star::star:
   1. Spring通过SqlSessionFactoryBuilder读取Mybatis的配置信息创建SqlSessionFactory，相当于数据库连接池。
   2. 通过SqlSessionFactory创建SqlSession。SqlSession的三个作用：1.获取Mapper接口。2.发送SQL给数据库。3.控制数据库事务。SqlSession相当于数据库连接对象。
   3. 然后通过SqlSession对象获取Mapper映射对象，Mapper映射是通过JDK代理创建一个代理类实现的。
   4. Mapper映射对象将SQL语句发送给Excutor执行器执行。
   5. Excutor执行器会调用具体的statementHandler用来执行查询操作，获取结果集并返回。  
 ![da7812cd.png](:storage\9cfa5682-2fcf-4377-806d-f6778e5d6cae\4c094da6.png)
  
- #### mybatis中的${}和#{}的区别
  - Mybatis的Sql语句传参有两种方式：``#{}和${}，#{}是预编译处理，${}是字符串替换。``
  - Mybatis在处理#{}时，会进行预编译，将sql中的#{}替换为?号，然后调用PreparedStatement的set方法来赋值；
  - Mybatis在处理${}时，就是把${}替换成变量的值。使用#{}可以有效的防止SQL注入，提高系统安全。

- #### MyBatis 一级缓存和二级缓存
  - 一级缓存是SqlSession级别的缓存，MyBatis默认开启一级缓存。在同一个SqlSession中，执行相同的SQL查询时；第一次会去查询数据库，并写入缓存，第二次会直接从缓存中取。如果执行了更新操作，SqlSession中的一级缓存会被清空。一级缓存是通过SqlSession中的hashmap实现的。
  - 二级缓存是Mapper(SqlSessionFactory)级别的缓存，默认没有开启，二级缓存需要bean实现序列化接口。多个SqlSession共享二级缓存，同样执行更新操作后，二级缓存会被清空。

- #### Spring中拦截器与过滤器的区别
  - 过滤器：Servlet中的过滤器Filter是实现了统一设置编码，简化操作；同时还可进行逻辑判断，如用户是否已经登陆、有没有权限访问该页面等等工作。它是随你的web应用启动而启动的，只初始化一次，以后就可以拦截相关请求，只有当你的web应用停止或重新部署的时候才销毁  
  - 拦截器：在面向切面编程的，拦截器可以对方法进行拦截，在方法调用的前后执行额外的业务逻辑。是基于JAVA的反射机制实现的。
  　1. 拦截器是基于Java的反射机制，过滤器是基于java的函数回调
　　2. 拦截器不依赖于servlet容器，而过滤器依赖于servlet容器
　　3. 拦截器只能对action请求起作用，过滤器几乎对所有的请求起作用
　　4. 拦截器可以访问action上下文，值栈里的对象，而过滤器不能访问
　　5. 在action生命周期中，拦截器可以被多次调用，过滤器只能在servlet溶初始化是调用一次
　　6. 拦截器可以获取IOC容器中的各个bean，过滤器不行，在拦截器中注入一个service可以调用逻辑业务。

- ### Spring中的事务原理 :star:
  1. Spring扫描事务注解或XML配置，通过事务管理器DateSourceTransactionManager创建事务
  2. 通过事务定义器TransactionDefinition设置事务隔离级别，事务传播特性、超时时间、回滚规则等事务属性
  3. 基于AOP生成spring事务代理类对定义了事务的方法进行拦截
  4. 事务方法执行成功事务提交，执行失败则根据事务回滚规则进行回滚。
  ![1efe91d4.png](:storage\9cfa5682-2fcf-4377-806d-f6778e5d6cae\e6969e07.png)
  
- #### 事务传播行为
  - 支持当前事务的情况：
    1. TransactionDefinition.PROPAGATION_REQUIRED： 如果当前存在事务，则加入该事务；如果当前没有事务，则创建一个新的事务。
    2. TransactionDefinition.PROPAGATION_SUPPORTS： 如果当前存在事务，则加入该事务；如果当前没有事务，则以非事务的方式继续运行。
    3. TransactionDefinition.PROPAGATION_MANDATORY： 如果当前存在事务，则加入该事务；如果当前没有事务，则抛出异常。（mandatory：强制性）
  - 不支持当前事务的情况：
    1. TransactionDefinition.PROPAGATION_REQUIRES_NEW： 创建一个新的事务，如果当前存在事务，则把当前事务挂起。
    2. TransactionDefinition.PROPAGATION_NOT_SUPPORTED： 以非事务方式运行，如果当前存在事务，则把当前事务挂起。
    3. TransactionDefinition.PROPAGATION_NEVER： 以非事务方式运行，如果当前存在事务，则抛出异常。
  - 其他情况：
    1. TransactionDefinition.PROPAGATION_NESTED： 如果当前存在事务，则创建一个事务作为当前事务的嵌套事务来运行；如果当前没有事务，则该取值等价于TransactionDefinition.PROPAGATION_REQUIRED。

- #### 事务
  - 事务：事务是由多条语句组成的原子性逻辑单元，事务中的语句要么同时执行成功，要么同时失败。
  - 事务的四大特性ACID:
    1. 原子性：事务是不可再分的原子性逻辑单元，确保事务中的语句要么全部执行成功，要么全部执行失败。
    2. 一致性：事务执行前后数据保持一致。
    3. 隔离性：多个事务之间互不影响。
    4. 持久性：一个事务提交后对数据的更改永久性保存到数据库中。

- #### SpingBoot自动配置实现
  - @EnableAutoConfiguration注解是实现springBoot自动配置的关键。
  1. Spring Boot程序的入口会加载主配置类，并且通过@EnableAutoConfiguration 开启自动配置的功能。该注解会引入EnableAutoConfigurationImportSelector类。
  2. 调用SpringFactoriesLoader类中的loadFactoryNames方法，该方法会扫描jar包路径下的META-INF/spring.factories 文件，把扫描到的这些文件内容包装成properties对象。再从properties中获取到EnableAutoConfiguration.class类（类名）对应的值，并且把他们添加到容器中。
  3. spring.factories里面的类都是自动配置类，SpringBoot会根据这些自动配置类去自动配置环境。


