title: Java并发总结
date: '2019-09-23 20:47:10'
updated: '2019-09-23 20:47:10'
tags: [总结, 面试]
permalink: /articles/2019/09/23/1569242830394.html
---
<!-- toc -->

- [Java并发](#Java并发)
      - [线程状态](#线程状态)
      - [线程的创建方式](#线程的创建方式)
      - [继承Tread类和Runnable接口区别](#继承Tread类和Runnable接口区别)
      - [线程池](#线程池)
      - [线程池拒绝策略](#线程池拒绝策略)
      - [线程池的好处](#线程池的好处)
      - [Thread类中的两个静态方法yield()和join()](#Thread类中的两个静态方法yield和join)
      - [wait()方法和sleep()方法的区别](#wait方法和sleep方法的区别)
      - [run()方法和start()的区别](#run方法和start的区别)
      - [线程池线程数的确定 N为cpu核心数](#线程池线程数的确定-N为cpu核心数)
    + [线程中断](#线程中断)
      - [Interrupt()方法](#Interrupt方法)
      - [interrupted()方法](#interrupted方法)
    + [Java内存模型](#Java内存模型)
    + [Volatile关键字](#Volatile关键字)
      - [指令重排](#指令重排)
    + [互斥同步(锁机制)](#互斥同步锁机制)
      - [synchronized关键字](#synchronized关键字)
      - [Synchronized 锁升级](#Synchronized-锁升级)
      - [synchronized和ReentrantLock锁的区别](#synchronized和ReentrantLock锁的区别)
      - [Reentrantlock实现原理](#Reentrantlock实现原理)
      - [AQS是如何实现公平锁和非公平锁的](#AQS是如何实现公平锁和非公平锁的)
    + [JUC并发组件-AQS](#JUC并发组件-AQS)
      - [Semaphore 信号量](#Semaphore-信号量)
      - [CountDownLatch 倒计时器、闭锁](#CountDownLatch-倒计时器、闭锁)
      - [CyclicBarrier 循环屏障](#CyclicBarrier-循环屏障)
    + [线程安全](#线程安全)
      - [不可变](#不可变)
      - [互斥同步 悲观锁](#互斥同步-悲观锁)
      - [非阻塞同步 乐观锁](#非阻塞同步-乐观锁)
      - [无同步方案](#无同步方案)
    + [Threadlocal :star::star::star:](#Threadlocal-starstarstar)
    + [ThreadLocal 内存泄漏问题 :star::star::star:](#ThreadLocal-内存泄漏问题-starstarstar)

<!-- tocstop -->
- # Java并发

- #### 线程状态
  - 新建（New）：创建后尚未启动。
  - 可运行（Runnable）：可能正在运行，也可能正在等待 CPU 时间片。包含了操作系统线程状态中的 Running 和 Ready。
  - 阻塞（Blocked）：等待获取一个排它锁，如果其线程释放了锁就会结束此状态。
  - 等待（Waiting）：等待其它线程显式地唤醒，否则不会被分配 CPU 时间片。
  - 计时等待（Timed Waiting）：无需等待其它线程显式地唤醒，在一定时间之后会被系统自动唤醒。
  - 死亡（Terminated）：可以是线程结束任务之后自己结束，或者产生了异常而结束。

- #### 线程的创建方式
  - 继承Tread类
  - 实现Runnable接口
  - 实现Callable接口：通过这种方式创建线程会有一个使用FutureTask封装的返回值，用于返回异步执行的结果。

- #### 继承Tread类和Runnable接口区别
  - 在Java中只能单继承，使用接口可以多实现。
  - 将线程任务的设置和执行进行了分离，实现了松耦合
  - 使用runnable接口创建增强了代码的重用性，可将runnable实例传递给其他执行器执行。
 
- #### 线程池
  - 线程池创建方式：Excutors,new ThreadPoolExcutor()

  -  new ThreadPoolExcutor()线程池参数
     1. corePoolSize：核心线程数
     2. maximumPoolSize：最大线程数
     3. keepAliveTime：非核心线程最大生存时间
     4. TimeUnit unit：时间单位
     5. BlockingQueue<Runnable> workQueue：任务阻塞队列
     6. ThreadFactory threadFactory：线程工厂，用于自定义线程创建的逻辑
     7. RejectedExecutionHandler handler：拒绝策略

  - Excutors工厂类：
    1. newCachedThreadPool：线程数量最大corePoolSize=0,maximumPoolSize=Integer.MAX_VALUE,workQueue为SynchronousQueue(同步队列)
        - 适合执行大量短期异步请求或负载较清的服务器。
    2. newFixedThreadPool 固定线程数量
        - corePoolSize=nThread，maximumPoolSize=n，ThreadWorkQueue为：new LinkedBlockingQueue无界阻塞队列
        - 执行长期的任务
    3. newSingleThreadExecutor：单线程
        - corePoolSize=1，maximumPoolSize=1，LinkedBlockingQueue
        - 一个任务一个任务执行的场景
    4. newScheduledThreadPool 线程存活时间无限制，经过延迟时间后，线程会重复执行。
        - corePoolSize=nThread，maximumPoolSize=Integer.MAX_VALUE，DelayedWorkQueue按照超时时间升序排列
        - 周期性执行任务的场景
      
     - SynchronousQueue是一个内部只能包含一个元素的队列。插入元素到队列的线程被阻塞，直到另一个线程从队列中获取了队列中存储的元素。
- #### 线程池拒绝策略
  - AbortPolicy 中止策略：线程池丢弃任务并抛异常。
  - DiscardPolicy 丢弃策略：线程池以静默方式丢弃任务。
  - DiscardOldestPolicy 丢弃最长任务策略：丢弃阻塞队列头部的任务，并再次提交被拒绝的任务。
  - CallerRunsPolicy 调用者执行策略：在 execute 方法的调用线程中运行被拒绝的任务。

- #### 线程池的好处
  1. 降低资源消耗：线程池通过重复利用已经创建的线程降低线程创建和销毁造成的资源消耗。
  2. 提高系统响应速度：当任务到达时，可直接使用空闲线程执行，节省了线程创建时间，提高了系统响应速度。
  3. 提高了线程的可管理性：通过线程池可以对多个线程进行统一管理。
进行回收。

- #### Thread类中的两个静态方法yield()和join()
  - yield()方法表示出让当前线程的CPU使用权。
  - join()方法表示等待其他线程执行完毕。

- #### wait()方法和sleep()方法的区别
  - wait()是Objcet类中的方法，sleep()是Thread类中的方法。
  - wait()方法会释放线程持有的锁，sleep()方法不会释放持有的锁。
  - sleep()方法必须捕获异常。

- #### run()方法和start()的区别
  - run()方法是类的普通方法，直接调用run()方法还是主线程执行，不会开启新线程。
  - start()方法用来启动一个新线程，使线程处于可运行状态。

- #### 线程池线程数的确定 N为cpu核心数
  - CPU密集型：线程数N+1
  - IO密集型：线程数2N+1

- ### 线程中断
  - #### Interrupt()方法
    - 通过调用一个线程的 interrupt() 来中断该线程，如果该线程处于阻塞、限期等待或者无限期等待状态(slepp、wait、join)，那么就会抛出 InterruptedException，从而提前结束该线程。但是不能中断 I/O 阻塞和 synchronized 锁阻塞。
  - #### interrupted()方法
    - 如果一个线程的 run() 方法执行一个无限循环，并且没有执行 sleep() 等会抛出 InterruptedException 的操作，那么调用线程的 interrupt() 方法就无法使线程提前结束。
    - 但是调用 interrupt() 方法会设置线程的中断标记，此时调用 interrupted() 方法会返回 true。因此可以在循环体中使用 interrupted() 方法来判断线程是否处于中断状态，从而提前结束线程。


- ### Java内存模型
  - 所有的变量都存储在主内存中，每个线程还有自己的工作内存，工作内存存储在高速缓存或者寄存器中，保存了该线程使用的变量的主内存副本拷贝。线程只能直接操作工作内存中的变量，不同线程之间的变量值传递需要通过主内存来完成。
![c3f3395d.png](:storage\c5e69ca2-c03c-4a64-9d69-0d61df4dcd54\c3f3395d.png)
  - 内存模型三大特性：原子性、可见性、有序性。

- ### Volatile关键字
  - Volatile关键字修饰变量，具有两重语义：
    1. **可见性：** 如果一个变量被volitale修饰，线程对该变量的操作完成之后会将该变量的值立刻刷新到主存中去，并使其他线程内部该变量的缓存无效，每次使用该变量都需要到主存中去获取。
      - **通过处理器嗅探技术实现：** 每个处理器通过嗅探在总线上传播的数据来检查自己缓存的值是不是过期了，当处理器发现自己缓存行对应的内存地址被修改，就会将当前处理器的缓存行设置成无效状态，当处理器对变量进行操作时，会从主存中读取。并且在操作完成后，会将变量的值刷新会主存中。
    2. **禁止指令重排：** JVM为了优化代码执行的效率，通常会对指令进行优化重排，为了保证多线程执行结果的争取行，通过插入特定类型的内存屏障Memory Barrier 指令来禁止volatile变量的指令重排，保证了变量操作的顺序性。

- #### 指令重排
  - 重排序发生在以下几个阶段(如果语句之间存在先后依赖关系则不进行重排序)：
    1. 编译器优化的重排序：编译器在不改变单线程程序语义放入前提下，可以重新安排语句的执行顺序。
    2. 指令级并行的重排序：现代处理器采用了指令级并行技术来将多条指令重叠执行。如果不存在数据依赖性，处理器可以改变语句对应机器指令的执行顺序。
    3. 内存系统的重排序：由于处理器使用缓存和读写缓冲区，这使得加载和存储操作看上去可能是在乱序执行。
    
- ### 互斥同步(锁机制)
  - #### synchronized关键字
    - **使用方式：**
      1. 作用于代码块：进入同步代码前要获得指定对象的锁。
      2. 作用于静态方法：进入同步代码前要获得当前类对象的锁。
      3. 作用于实例方法：进入同步代码前要获得当前实例的锁。
    - **底层实现**：
      1. 对于同步代码块，JVM通过生成monitorenter和monitorexit两个字节码指令指令实现同步。而实例方法和静态方法的同步是通过读取运行时常量池中的 ACC_SYNCHRONIZED 标志实现的。
      2. Java对象头中的mark word中存储了指向monitor的指针，mark word中包含了存储着对象的HashCode、分代年龄、锁标记位等信息，锁的升级也是通过Mark Word中的锁标志位实现的。

  - #### Synchronized 锁升级
    - **锁升级过程：** 偏向锁->轻量级锁->自旋->重量级锁
      1. 当线程第一次获取锁对象时，会将对象头中的锁标志位设为偏向锁，同时使用CAS操作将锁对象的持有者设为当前线程。
      2. 如果CAS操作成功，则同一线程再次获取同一个对象锁，虚拟机都可以不再进行任何同步操作。
      3. 如果有其他线程尝试获取该对象锁，则偏向锁会升级为轻量级锁，线程通过CAS自旋操作尝试获取锁，如果在规定自旋次数内获得该锁，则锁仍会处于轻量级锁状态，如果CAS自旋获取锁失败则锁会升级为重量级锁。
      4. 需要获取锁对象的监视器进行互斥同步操作。
  - #### synchronized和ReentrantLock锁的区别
    1. synchronized是Java关键字，是JVM层面的实现。lock锁是API实现的。
    2. synchronized是隐式锁，锁使用完毕后会自动释放。lock锁是显式锁，必须显式的进行加锁和解锁操作。
    3. synchronized不响应中断。lock响应中断。
    4. synchronized只能绑定一种状态。lock锁可以通过condition对象绑定多个状态，实现更加灵活的控制。
    5. synchronized是非公平锁。lock锁可以实现公平锁。
  - #### Reentrantlock实现原理
    - lock锁是采用模板方法基于AQS实现的，通过volatile修饰同步状态变量state控制线程同步状态，并且采用CAS实现对state变量的原子性操作，最后使用AQS来管理阻塞等待线程。
    - **lock锁加锁的过程**
      1. 当前线程调用lock()方法尝试进行加锁操作时，首先通过CAS操作将state设置为1，如果成功则将锁的占有线程设置为当前线程。如果失败则调用acquire()方法尝试获取锁。
      2. acquie()方法会调用TryAcquire()实现，首先获取state的值，如果state = 0，则表示锁未被占用，直接通过CAS操作将state设为1，并将当前线程设为锁的持有线程。如果state不为0，则表示锁已经被占用，判断当前线程是否为锁的持有线程，如果是则将state加1， 如果锁的持有线程不是当前线程，则获取锁失败。
      3. 锁获取失败后将通过addWaiter()方法将当前线程封装为Node节点，加入到阻塞队列中，接着调用acquireQueued()方法不断的自旋去判断当前线程是否到达头结点，如果到达则通过TryAcquire()方法直接尝试获取锁，获取成功则线程出队列开始执行。
  - #### AQS是如何实现公平锁和非公平锁的
    - NonfairSync中的lock方法首先会通过CAS修改state,而FairSync则直接通过acquire方法获取，如果获取失败，则将该线程加入到阻塞队列中进行排队。 

- ### JUC并发组件-AQS
  - #### Semaphore 信号量
    - 用于控制同时访问某个共享资源的线程数量。
    - 参数permits许可证数量
    - 步骤：
      1. 创建Semaphore信号量对象并设置permits变量的值，表示可访问线程数量。
      2. 每当线程调用semaphore.acquire()方法，如果获取成功则state-1，如果state小于等于0，则线程加入到队列中阻塞等待。
      3. 线程执行结束后通过semaphore.relaase()方法释放资源，state+1。
  
  - #### CountDownLatch 倒计时器、闭锁
    - 用于控制一个或多个线程等待其他线程执行完毕。
    - count变量表示当前计数器的值，当计数器为0时唤醒等待线程。
    - 步骤：
      1. 创建CountDownLatch倒计时器对象并设置count倒计时数值，线程调用调用latch.await()方法进入等待状态。
      2. 每当其他线程调用latch.countDown()方法，count-1，当count=0时，唤醒等待线程。
      3. 倒计时器只能使用一次。

  - #### CyclicBarrier 循环屏障
    - 用来控制多个线程互相等待，只有当多个线程都到达时，这些线程才会继续执行。
    - parties变量表示需要等待的线程数。
    - 步骤：
      1. 创建cyclicBarrier循环屏障对象并设置parties需要等待的线程数。
      2. 线程调用cyclicBarrier.await()方法等待，每当等待线程数量到达指定线程数，则等待线程统一继续执行。
      3. 循环屏障重置。
    
- ### 线程安全
  - #### 不可变
    - 不可变（Immutable）的对象一定是线程安全的，不需要再采取任何的线程安全保障措施。
    - 不可变的类型：
      - final 关键字修饰的基本数据类型
      - String
      - 枚举类型
  - #### 互斥同步 悲观锁
    - synchronized 和 ReentrantLock。
  - #### 非阻塞同步 乐观锁
    - CAS：通过机器原语指令实现CAS操作的原子性，CAS 指令需要有 3 个操作数，分别是内存地址 V、旧的预期值 A 和新值 B。当执行操作时，只有当 V 的值等于 A，才将 V 的值更新为 B。
    - AtomicInteger原子类：J.U.C 包里面的整数原子类 AtomicInteger 的方法调用了 Unsafe 类的 CAS 操作。
    - ABA问题：如果一个变量初次读取的时候是 A 值，它的值被改成了 B，后来又被改回为 A，那 CAS 操作就会误认为它从来没有被改变过。 解决方法：通过版本号。
  - #### 无同步方案
    - 栈封闭：多个线程访问同一个方法的局部变量时，不会出现线程安全问题，因为局部变量存储在虚拟机栈中，属于线程私有的。
    - 线程本地存储（Thread Local Storage）：可以使用 java.lang.ThreadLocal 类来实现线程本地存储功能。
    
- ### Threadlocal :star::star::star:
  - Threadlocal提供了变量在线程本地存储的功能，每个访问threadlocal变量的线程都会拥有一个该变量的副本。
  - Thread类中含有一个TreadLocalMap用于存储threadlocal变量，其中key为threadLocal实例，value为使用set()设置的值。
  - ### ThreadLocal 内存泄漏问题 :star::star::star:
  - ThreadLocalMap中key是弱引用，弱引用会在GC时被回收，这个时候就会出现Entry中Key已经被回收，出现一个Key为null的情况，从而无法通过Key获取Value。在使用线程池的情况下，线程重复使用，那么其内部的ThreadLocalMap对象也一直存在，就会存在强引用关联entry和value(Thread->ThreadLocalMap->Entry->Value)，导致entry和value不会被回收，从而出现内存泄漏。
