title: Java基础
date: '2019-09-23 20:46:40'
updated: '2019-09-23 20:46:40'
tags: [面试, 总结]
permalink: /articles/2019/09/23/1569242800535.html
---
<!-- toc -->

- [Java基础](#Java基础)
      - [抽象类和接口的区别](#抽象类和接口的区别)
    + [基础类型和包装类型](#基础类型和包装类型)
      - [自动拆装箱的实现](#自动拆装箱的实现)
      - [Integer类型的缓存池](#Integer类型的缓存池)
    + [String](#String)
    + [String不可变的好处 :star:](#String不可变的好处-star)
    + [String、StringBuffer、StringBuilder](#String、StringBuffer、StringBuilder)
      - [StringBuffer和StringBuilder](#StringBuffer和StringBuilder)
    + [Object类中的方法](#Object类中的方法)
      - ["=="与euqals()方法](#""与euqals方法)
      - [为什么要同时重写hahCode()和equals()方法 :star:](#为什么要同时重写hahCode和equals方法-star)
      - [toString()方法](#toString方法)
    + [wait()和notify()方法 :star::star::star:](#wait和notify方法-starstarstar)
      - [finalize()方法](#finalize方法)
    + [Java关键字](#Java关键字)
      - [final关键字](#final关键字)
      - [static关键字](#static关键字)
      - [final、finally和finalize()的区别](#final、finally和finalize的区别)
    + [Java反射机制](#Java反射机制)
      - [反射机制的功能](#反射机制的功能)
      - [如何访问私有属性](#如何访问私有属性)
      - [反射机制的优缺点](#反射机制的优缺点)
      - [Class.forName()和ClassLoader.loadClass()方法的区别](#ClassforName和ClassLoaderloadClass方法的区别)
    + [Java泛型](#Java泛型)
      - [Java泛型的实现原理](#Java泛型的实现原理)
      - [受限泛型](#受限泛型)
    + [Java注解](#Java注解)
    + [序列化](#序列化)
      - [为什么要序列化](#为什么要序列化)
      - [如何序列化](#如何序列化)

<!-- tocstop -->
- # Java基础

- #### 抽象类和接口的区别
  - 抽象类是对同一种类型的抽象，用来描述同一种类型应该具有的基本属性和方法。接口用来描述定义类时的规范。
  - 抽象类只能单继承，接口可以多实现。
  - 接口中的字段和方法只能被public修饰，抽象类没有限制
  - 接口中的字段默认都是 static 和 final 的，抽象类能够含有非final变量。

- ### 基础类型和包装类型
  - Java将基础数据类型转换为相应引用类型，使其具有更多的功能，并能够通过对象调用的方式进行使用。
  - #### 自动拆装箱的实现
    - 自动装箱：通过xxx.valueOf()方法实现
    - 自动拆箱：通过x.intValue()方法实现
  - #### Integer类型的缓存池
    - Integer 缓存池的大小默认为 -128~127。在该范围内，会直接到缓存池中获取数据，超过该范围会new一个新对象。

- ### String
  - String类被声明为final，不能够被继承。因为String是高引用率类，不能够被继承提高了效率。
  - 不变性：采用final修饰的字符数组实现。
  - ### String不可变的好处 :star:
    - 为了实现字符串常量池，减少字符串对象的重复创建。
    - 为了多线程安全。
    - 可缓存hash值，Stirng类型经常在MAP中被使用，不可变的特性可以使得 hash 值也不可变，因此只需要进行一次计算，提高了效率。
    - 保证在网络中传递参数的安全性。

- ### String、StringBuffer、StringBuilder
  - String是不可变的，而StringBuffer和StringBuilder是可变的。
  - String和StringBuffer是线程安全的，StringBuilder是线程不安全的。
    - #### StringBuffer和StringBuilder
      - StringBuffer和StringBuilder都是通过字符数组实现的。
      - StringBuffer通过synchronized实现多线程安全，效率低。StringBuilder是线程不安全的，效率高。
  
- ### Object类中的方法
  - equals()
  - hashCode()
  - toString()
  - wait()
  - notify()
  - clone()
  - fianlize()
  - #### "=="与euqals()方法
    - 对于基本数据类型，==比较的是变量的值是否相等，基本数据类型没有equals()方法。
    - 对于引用数据类型，==是判断两个对象引用的地址是否相等。Object类中的equals()方法默认是采用==实现的，通常其他类要重写equals方法，用来比较两个对象的内容是否相等。
  - #### 为什么要同时重写hahCode()和equals()方法 :star:
    - hashCode() 返回哈希值，而 equals() 是用来判断两个对象是否等价。在哈希表结构中，如果两个对象相等则哈希值一定相等，但是哈希值相同的两个对象不一定相等。因此在重写equals() 方法时应当同时重写hashCode()方法，保证相等的两个对象的哈希值也相等。
  - #### toString()方法
    - 将对象的属性值按照一定的格式输出。如果不重写toString()方法，默认输出的是：对象的全限定类名+@+对象哈希值的无符号十六进制表示。
  - ### wait()和notify()方法 :star::star::star:
  - wait()和notify()方法是Java中最基本的线程通信方式，wait()方法用于挂起一个线程，notify()方法用于唤醒线程。
  - **wait()方法和notify()方法必须在synchronized同步代码中才能能够调用**
    - notify 和wait方法必须在synchronized里使用是一种安全设计，通过synchronized保证同步代码执行的有序性和原子性，避免notify先于wait方法执行，导致调用wait()方法的线程不会被唤醒。
  - #### finalize()方法
    - 在进行GC时，会调用被回收对象的finalize()方法对对象进行回收。

- ### Java关键字
  - #### final关键字
    - 修饰类：表示该类不能够被继承。
    - 修饰方法：表示该方法不能够被重写。
    - 修饰变量：对于基本数据类型表示数值不可变；对于引用数据类型表示对象引用不可变，也就不能引用其它对象，但是被引用的对象本身是可以修改的。
  
  - #### static关键字
    - 静态代码块：只在类的初始化时执行一次。通常用于驱动加载。
    - 静态变量：表示该变量为类变量，类的所有实例共享该变量。
    - 静态方法：表示方法属于类，可以直接通过类名调用。在静态方法中不能调用非静态方法和变量。
    - 初始化顺序：静态变量和静态语句块优先于实例变量和普通语句块。

- #### final、finally和finalize()的区别
  - fianl：final是java中的关键字，可以修饰类、方法和变量。
    1. 修饰类表示该类不能被继承。
    2. 修饰方法表示该方法不能被重写。
    3. 修饰变量表示该变量为常量，不能被更改。
  - finally：finally是java异常处理的一部分，它只能用在try/catch语句中，并且附带一个语句块，表示这段语句最终一定会被执行（不管有没有抛出异常），经常被用在需要释放资源的情况下。
  - finalize():finalize()是在java.lang.Object里定义的。GC时会调用被回收对象的finalize()方法对对象。 

- ### Java反射机制
  - Java反射机制是在Java程序运行过程中动态获取类的信息和动态调用类的方法的技术。
  - 通常通过Class.forName("全限定类名").newInstance()动态获取类的对象实例。拿到对象之后就可以调用方法获取类的构造函数、属性和方法。
  - #### 反射机制的功能
    - 在运行时判断任意一个对象所属的类；
    - 在运行时构造任意一个类的对象；
    - 在运行时判断任意一个类所具有的成员变量和方法；
    - 在运行时调用任意一个对象的方法；生成动态代理。
  - #### 如何访问私有属性
    - 暴力反射，通过setAccessible(true)方法取消反射时的访问检查。
  - #### 反射机制的优缺点
    - 优点：通过反射机制可以在运行时确定类型，绑定对象，是java多态的体现，提高了程序的灵活性和扩展性。
    - 缺点：破坏了java的封装性，有安全隐患。
  - #### Class.forName()和ClassLoader.loadClass()方法的区别
    - 使用Class.forName()获取类时会执行类的初始化操作。
    - ClassLoader.loadClass()不会执行类的初始化。
  
- ### Java泛型
  - #### Java泛型的实现原理
    - 泛型的意思就是参数化类型，通过泛型创建的接口、类、方法、集合等可以指定要操作的数据类型。
    - 泛型是通过泛型擦除实现的，泛型会在编译期被转换为Object类型
    - 泛型的好处：
    1. 消除了代码中的强制类型转换，自动确保类型安全，并且提高了代码的重用性。
    2. 实现了类型检查，将运行期错误转化为编译期错误。
  - #### 受限泛型
    1. ``<T extends xxx> ``:限制泛型的上限类型
    2. ``<T super xxx>``:限制泛型的下限类型

- ### Java注解
  - 注解也叫元数据，将信息或者元数据和程序关联，对代码进行说明。
  - 注解的实现原理
    - 程序通过反射获取类的AnnotatedElement注解元素对象之后，调用对象的方法访问注解信息。
  - 注解的类型：
     -  普通注解：Override
     -  元注解：用于定义注解的注解，包括@Retention（标明注解被保留的阶段）、@Target（标明注解使用的范围）、@Inherited（标明注解可继承）、@Documented（标明是否生成javadoc文档）
     -  自定义注解
 ```
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface TestAnnonation {
   String name() default "";
   int Id()  default 0;
}
```

- ### 序列化
  - 什么是序列化和反序列化
    - 序列化：把对象转换为字节序列的过程称为对象的序列化。
    - 反序列化：把字节序列恢复为对象的过程称为对象的反序列化。
  - 为什么要序列化
    - 序列化机制可以将Java对象转换为数据流用来保存在磁盘上或者通过网络传输。这使得对象可以脱离程序独立存在。
  - 如何序列化
    - 实现了Serializable接口的类，可以通过两个步骤序列化该对象：
    - 创建建立在其他节点流上的ObjectOutputStream
    - 调用ObjectOutputStream对象的writeObject()方法输出可序列化对象
   
```
//创建ObjectOutputStream输出流
ObjectOutputStream oos = new ObejctOutputStream(new FileOutputStream("object.txt"));

//将一个Person对象输出到输出流中
oos.writeObject(per);
```
